# Solaris Gameserver
This was the gameserver used for Solaris 10.00.