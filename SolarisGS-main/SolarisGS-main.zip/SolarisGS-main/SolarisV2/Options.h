#pragma once
constexpr auto PlaylistPath = "/Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo";
constexpr auto Port = 7777;