#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x340 - 0x340)
// WidgetBlueprintGeneratedClass AccountNotFound.AccountNotFound_C
class UAccountNotFound_C : public UFortAccountNotFound
{
public:

	static class UClass* StaticClass();
	static class UAccountNotFound_C* GetDefaultObj();

};

}


