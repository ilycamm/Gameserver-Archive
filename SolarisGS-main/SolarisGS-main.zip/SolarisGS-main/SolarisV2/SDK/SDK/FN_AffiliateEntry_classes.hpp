#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xB60 - 0xB60)
// WidgetBlueprintGeneratedClass AffiliateEntry.AffiliateEntry_C
class UAffiliateEntry_C : public UFortAffiliateEntry
{
public:

	static class UClass* StaticClass();
	static class UAffiliateEntry_C* GetDefaultObj();

};

}


