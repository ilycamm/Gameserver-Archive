#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3C - 0x3C)
// BlueprintGeneratedClass AnimNotify_FootStep_Left.AnimNotify_FootStep_Left_C
class UAnimNotify_FootStep_Left_C : public UAnimNotify_FootStep_C
{
public:

	static class UClass* StaticClass();
	static class UAnimNotify_FootStep_Left_C* GetDefaultObj();

};

}


