#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2D8 - 0x2D8)
// BlueprintGeneratedClass Announce_Storm2018Cine.Announce_Storm2018Cine_C
class AAnnounce_Storm2018Cine_C : public AAnnounce_EventCine_C
{
public:

	static class UClass* StaticClass();
	static class AAnnounce_Storm2018Cine_C* GetDefaultObj();

};

}


