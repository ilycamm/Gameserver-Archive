#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
class UArrowCursorWidget_C : public UUserWidget
{
public:

	static class UClass* StaticClass();
	static class UArrowCursorWidget_C* GetDefaultObj();

	struct FSlateBrush GetBackground_0();
};

}


