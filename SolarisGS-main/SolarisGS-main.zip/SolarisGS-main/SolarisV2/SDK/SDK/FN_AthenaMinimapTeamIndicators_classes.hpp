#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x588 - 0x588)
// BlueprintGeneratedClass AthenaMinimapTeamIndicators.AthenaMinimapTeamIndicators_C
class UAthenaMinimapTeamIndicators_C : public UFortMiniMapTeamIndicators
{
public:

	static class UClass* StaticClass();
	static class UAthenaMinimapTeamIndicators_C* GetDefaultObj();

};

}


